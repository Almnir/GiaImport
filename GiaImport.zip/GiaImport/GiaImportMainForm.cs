﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace GiaImport
{
    public partial class GiaImportMainForm : Form
    {
        Dictionary<string, FileInfo> loadedFiles = new Dictionary<string, FileInfo>();
        DataSet mainDataSet = new DataSet();
        public GiaImportMainForm()
        {
            InitializeComponent();
        }

        private void filesOpenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "XML Files (.xml)|*.xml|All Files (*.*)|*.*";
            openFileDialog.FilterIndex = 1;

            openFileDialog.Multiselect = true;

            DialogResult userClicked = openFileDialog.ShowDialog();

            if (userClicked == DialogResult.OK)
            {
                loadedFiles.Clear();
                foreach (string file in openFileDialog.FileNames)
                {
                    FileInfo fi = new FileInfo(file);
                    loadedFiles.Add(file, fi);
                    ListViewItem lvi = new ListViewItem(fi.Name);
                    fileListView.Items.Add(lvi);
                }
            }
        }

        private void simpleImportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dictionary<string, FileInfo> selectedFiles = new Dictionary<string, FileInfo>();
            ListView.SelectedListViewItemCollection selected = fileListView.SelectedItems;
            foreach (ListViewItem sel in selected)
            {
                foreach (var lf in loadedFiles)
                {
                    if (lf.Value.Name.Equals(sel.Text))
                    {
                        selectedFiles.Add(lf.Key, lf.Value);
                    }
                }
            }
            foreach (string sel in selectedFiles.Keys)
            {
                DataTable dt = new DataTable();
                dt.ReadXml(sel);
                mainDataSet.Tables.Add(dt);
            }
            SqlConnection connection = new SqlConnection("DB ConnectionSTring");
            SqlBulkCopy sbc = new SqlBulkCopy(connection);
            sbc.DestinationTableName = "yourXMLTable";
            sbc.
        }

        public void ProcessFileWithAction(string filePath, Action<XDocument> action)
        {
            var settings = new XmlReaderSettings { IgnoreComments = true, IgnoreWhitespace = true };
            using (var reader = XmlReader.Create(filePath, settings))
            {
                reader.MoveToContent();

                var root = new XElement(reader.Name, new[]
                    {
                        new XAttribute(XNamespace.Xmlns + "xsi", _xsi.NamespaceName),
                        new XAttribute(XNamespace.Xmlns + "xsd", _xsd.NamespaceName)
                    });

                var batchOfXml = new XDocument(root);

                /* Грузим пачками в БД */
                //if (typeof (TDto) == typeof (StationWorkersDto)) _batchSize = 1;
                foreach (var batch in new XmlBatchReader(50000).ReadBatch(reader, typeof(object).Name, _batchSize))
                {
                    root.Add(batch);
                    action(batchOfXml);
                    root.RemoveAll();
                }
            }
        }
        public void BulkWriteToDb(string connectionString, DataTable dataTable)
        {
            SqlTransaction tran = null;
            SqlConnection connection = null;
            try
            {
                using (connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (tran = connection.BeginTransaction())
                    {
                        using (SqlBulkCopy bcp = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, tran))
                        {
                            bcp.DestinationTableName = dataTable.TableName;
                            bcp.BatchSize = 500;
                            bcp.NotifyAfter = 1000;
                            bcp.SqlRowsCopied +=
                                new SqlRowsCopiedEventHandler(bulkCopy_SqlRowsCopied);
                            bcp.WriteToServer(dataTable);
                        }
                        tran.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                if (tran != null)
                {
                    tran.Rollback();
                }
                throw new BulkException("Ошибка в методе BulkWriteToDb.", ex);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }

        static async Task<int> HandeBulkCopyAsync(string connectionString, DataTable dataTable)
        {
            int count = 0;
            SqlTransaction tran = null;
            SqlConnection connection = null;
            try
            {
                using (connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (tran = connection.BeginTransaction())
                    {
                        using (SqlBulkCopy bcp = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, tran))
                        {
                            bcp.DestinationTableName = dataTable.TableName;
                            bcp.BatchSize = 500;
                            bcp.NotifyAfter = 1000;
                            await bcp.WriteToServerAsync(dataTable);
                            count++;
                        }
                        tran.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                if (tran != null)
                {
                    tran.Rollback();
                }
                throw new BulkException("Ошибка в методе BulkWriteToDb.", ex);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return count;
        }

        private void bulkCopy_SqlRowsCopied(object sender, SqlRowsCopiedEventArgs e)
        {
            throw new NotImplementedException();
        }

        public static DataTable LoadXmlToDataTable(string fileName)
        {
            DataTable dataTable = new DataTable();
            try
            {
                dataTable.ReadXml(fileName);
            }
            catch (Exception ex)
            {
                throw new LoadXMLException("Всё плохо!", ex);
            }
            return dataTable;
        }

        private void chooseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
